# tdskill 2.1.0

一个 zip 装一个 skill。本压缩包按使用场景分了几个文件夹，按需把里面的 zip 逐个拖进 Agent 的「上传技能」窗口即可。

## 必装入口

- **tdskill** — 主入口，根据你的问题自动路由到合适的诊断 skill。其他 skill 都依赖它，先装这个。

## 认知与展示

- **tds-attraction** — 认知提升诊断（找到吸引力层面的认知卡点）
- **tds-display** — 展示面与人设打造诊断（检查信号传递是否正确）

## 互动与连接

- **tds-approach** — 搭讪诊断（自然地开始一次交流）
- **tds-chat** — 聊天诊断（建立真正有连接的对话）
- **tds-date** — 约会诊断（把约会变成有效的情感传递）

## 关系管理

- **tds-relationship** — 关系管理诊断（建立可持续发展的长期关系）

## 学习方法

- **tds-learn** — 学习方法诊断（把知识转化为行为改变）

---

每个 zip 解压后根级是 SKILL.md（带 YAML frontmatter，含 name + description），格式遵循 Anthropic Skills 规范。
